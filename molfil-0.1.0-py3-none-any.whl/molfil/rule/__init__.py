import os
from . import core

# Determine the path to the current module (__init__.py)
MODULE_DIR = os.path.dirname(__file__)

# Set path to ASSETS_DIR as: MODULE_DIR + "/assets/"
ASSETS_DIR = os.path.join(MODULE_DIR, "assets")

DEFAULT_CONFIG = {
    "has_unwanted_substructure": {
        "file": os.path.join(ASSETS_DIR, "unwanted_substructures.csv"),
        "smarts_col": "smarts",
    },
    "has_large_ring": {
        "max_allowed_size": 8,
    },
    "has_non_good_ring": {
        "file": os.path.join(ASSETS_DIR, "good_rings.csv"),
        "smarts_col": "SMARTS_priya",
    },
    "run": [
        "has_pains",
        "has_unwanted_substructure",
        "has_non_good_ring",
        "fails_ro8",
    ],
}

def filter(all_smiles, config=None):
    if config is None:
        config = DEFAULT_CONFIG

    run_config = config["run"]
    all_molecules = [core.smiles_to_molecule(smiles) for smiles in all_smiles]

    # Removing SMILES that were not convertible
    all_smiles = [smile for (smile, molecule) in zip(all_smiles, all_molecules) if molecule is not None]
    all_molecules = [molecule for molecule in all_molecules if molecule is not None]

    result = {"smiles": all_smiles}

    if "has_pains" in run_config:
        has_pains = core.has_pains(all_molecules)
        result["has_pains"] = has_pains
    if "has_unwanted_substructure" in run_config:
        has_unwanted_substructure = core.has_unwanted_substructure(all_molecules, **config["has_unwanted_substructure"])
        result["has_unwanted_substructure"] = has_unwanted_substructure
    if "fails_ro8" in run_config:
        fails_ro8 = core.fails_ro8(all_molecules)
        result["fails_ro8"] = fails_ro8
    if "has_large_ring" in run_config:
        has_large_ring = core.has_large_ring(all_molecules, **config["has_large_ring"])
        result["has_large_ring"] = has_large_ring
    if "has_non_good_ring" in run_config:
        has_non_good_ring = core.has_non_good_ring(all_molecules, **config["has_non_good_ring"])
        result["has_non_good_ring"] = has_non_good_ring

    final_result = [{"smiles": smiles} for smiles in result["smiles"]]
    for key, values in result.items():
        if key == "smiles":
            continue
        for i, value in enumerate(values):
            final_result[i][key] = value

    return final_result
