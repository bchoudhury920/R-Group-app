import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors, Draw
from rdkit.Chem.Draw import MolsToGridImage
from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams
from rdkit import RDLogger


# Disable warnings from rdkit
RDLogger.DisableLog('rdApp.*')

def smiles_to_molecule(smiles):
    """
    Converts a SMILES string into a molecule object
    """
    return Chem.MolFromSmiles(smiles)


def smarts_to_molecule(smarts):
    """
    Converts a SMARTS string into a molecule object
    """
    return Chem.MolFromSmarts(smarts)


def has_pains(molecules):
    """
    Filters a list of molecules using the PAINS filter.

    Parameters
    ----------
    molecules : list
        List of rdkit.Chem.rdchem.Mol objects.
    
    Returns
    -------
    list
        List of booleans, where True indicates that the molecule is PAINS compliant.
    """
    
    params = FilterCatalogParams()
    params.AddCatalog(FilterCatalogParams.FilterCatalogs.PAINS)
    catalog = FilterCatalog(params)
    
    return [catalog.GetFirstMatch(molecule) is not None for molecule in molecules]


def has_unwanted_substructure(molecules, **config):
    """
    Filters a list of molecules using a manually curated unwanted substructures list.

    Parameters
    ----------
    molecules : list
        List of rdkit.Chem.rdchem.Mol objects.
    config : dict
        Dictionary of configuration parameters.
        - file : str - The path to the CSV file containing the list of unwanted substructures.
        - smarts_col : str - The column name of the SMARTS string in the CSV file. ***Default: smarts***
    
    Returns
    -------
    list
        List of booleans, where True indicates that the molecule matches some unwanted substructures.
    """
    
    _df = pd.read_csv(config["file"], usecols=[config.get("smarts_col", "smarts")])
    unwanted_substructures = _df.iloc[:, 0].to_list()
    unwanted_substructures = [smarts_to_molecule(substructure) for substructure in unwanted_substructures]
    
    results = []
    for molecule in molecules:
        match = False
        for unwanted_substructure in unwanted_substructures:
            if molecule.HasSubstructMatch(unwanted_substructure):
                match = True
                break
        results.append(match)
   
    return results


def fails_ro8(molecules, **config):
    """
    Filters a list of molecules using the RO8 filter.

    Parameters
    ----------
    all_molecules : list
        List of rdkit.Chem.rdchem.Mol objects.
    config : dict
        Dictionary of configuration parameters.
    
    Returns
    -------
    list
        List of booleans, where True indicates that the molecule fails the RO8 filter.
    """
    
    results = []
    for molecule in molecules:
        molecular_weight = Descriptors.ExactMolWt(molecule)
        n_hba = Descriptors.NumHAcceptors(molecule)
        n_hbd = Descriptors.NumHDonors(molecule)
        logp = Descriptors.MolLogP(molecule)
        rotBond = Descriptors.NumRotatableBonds(molecule)
        QED = Descriptors.qed(molecule)
        TPSA = Descriptors.TPSA(molecule)
        n_Ar = Descriptors.NumAromaticRings(molecule)
        
        # TODO: make filter thresholds configurable
        conditions = [molecular_weight <= 400, n_hba <= 10, n_hbd <= 5, logp <=3.5, n_Ar >=1 & n_Ar <=3, rotBond <=10, TPSA <=140, QED >=0.5, (n_hba + n_hbd) <= 10]
        ro8_fulfilled = sum(conditions) >= 9
        
        results.append(not ro8_fulfilled)
    
    return results


def has_large_ring(molecules, **config):
    """
    Filters a list of molecules using the large rings filter.

    Parameters
    ----------
    all_molecules : list
        List of rdkit.Chem.rdchem.Mol objects.
    config : dict
        Dictionary of configuration parameters.
        - max_allowed_size : int - The threshold for the largest allowed ring size.
    
    Returns
    -------
    list
        List of booleans, where True indicates that the molecule has a large ring.
    """
    
    results = []
    for molecule in molecules:
        # TODO: check if this can be made more efficient
        all_rings = molecule.GetRingInfo().AtomRings()
        if len(all_rings) == 0:
            results.append(False)
            continue
        all_rings_len = [len(r) for r in all_rings]
        results.append(max(all_rings_len) > config["max_allowed_size"])
    
    return results

def has_non_good_ring(molecules, **config):
    """
    Filters a list of molecules based on presence of ring(s) that are not part of the good rings list

    Parameters
    ----------
    all_molecules : list
        List of rdkit.Chem.rdchem.Mol objects.
    config : dict
        Dictionary of configuration parameters.
        - file : str - The path to the CSV file containing the list of good rings.
        - smarts_col : str - The column name of the SMARTS string in the CSV file. ***Default: smarts***
    
    Returns
    -------
    list
        List of booleans, where True indicates that the molecule has a non-good ring.
    """
    
    _df = pd.read_csv(config["file"], usecols=[config.get("smarts_col", "smarts")])
    _df = _df.dropna()
    good_rings = _df.iloc[:, 0].to_list()
    good_rings = [smarts_to_molecule(substructure) for substructure in good_rings]
    
    def _handle_fused_and_spiro_rings(ring_info):
        _ring_info = [set(r) for r in ring_info]
        _ring_info.sort(key=min)
        for i in range(len(_ring_info)):
            for j in range(i+1, len(_ring_info)):
                r1, r2 = _ring_info[i], _ring_info[j]
                if r1 is None or r2 is None:
                    continue
                if r1 & r2:
                    _ring_info[i] |= r2
                    _ring_info[j] = None
        _ring_info = [r for r in _ring_info if r is not None]
        return _ring_info
    
    results = []
    for molecule in molecules:
        ring_info = molecule.GetRingInfo().AtomRings()
        ring_info = _handle_fused_and_spiro_rings(ring_info)
        for ring in good_rings:
            matched_rings = molecule.GetSubstructMatches(ring)
            # filtering out extra fused/spiro rings
            matched_rings = [set(r) for r in matched_rings if set(r) in ring_info]
            if matched_rings:
                # print(ring_info, matched_rings)
                ring_info = [r for r in ring_info if r not in matched_rings]
                # print(ring_info)
        if ring_info:
            _has_non_good_ring = True
        else:
            _has_non_good_ring = False
        results.append(_has_non_good_ring)

    return results